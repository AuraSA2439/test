// const CONFIG = {
//   BASE_URL: 'https://story-api.dicoding.dev/v1',
// };

export const BASE_URL = 'https://story-api.dicoding.dev/v1';

export const ACCESS_TOKEN_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJ1c2VyLWtUMnVIX1NQNzNaTzItaHQiLCJpYXQiOjE3NjE2NDM2NTR9.MBKKe0dZS8LY5tg9rnHeoiPsoeuY7qLkAjsZuvxFm28';

export const MAP_SERVICE_API_KEY = 'kqUWE7CM9sjjbacId3dI';

export const VAPID_PUBLIC_KEY = 'BCCs2eonMI-6H2ctvFaWg-UYdDv387Vno_bzUzALpB442r2lCnsHmtrx8biyPi_E-1fSGABK_Qs_GlvPoJJqxbk';

// export default CONFIG;
